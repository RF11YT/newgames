# NewGames — Site Catálogo (sem carrinho)

Catálogo de games mobile-first, tema synthwave/cyberpunk, com um único caminho de compra: WhatsApp.

## Identidade visual
- Fundo `#0A0E27`, superfícies `#12183A` / `#1A1A1A`, texto branco.
- Neon: azul `#00A8FF`, roxo `#9D00FF`, magenta `#FF00E0`; degradê azul→roxo→magenta com glow suave em botões e destaques.
- Títulos Raleway Black Italic, corpo Inter (Google Fonts via `<link>` no root).
- Cards em glassmorphism escuro, borda neon fina que acende no hover + leve elevação.
- Grade retrô em perspectiva e partículas discretas nas seções de destaque.
- Todos os valores viram tokens no design system (nada de cor hardcoded nos componentes).

## Regra do botão de compra
Único CTA de produto: abre `https://wa.me/55SEUNUMERO` com texto codificado
`Olá NewGames! Tenho interesse no {nome} ({preço}). Está disponível?`.
Helper central `waLink()` usado por todos os botões. Sem carrinho, checkout, login ou pagamento.

## Estrutura da página (rota `/`)
1. Barra superior fina: endereço, horário, "Loja física".
2. Header sticky: logo, busca central (filtra os produtos exibidos), menu de categorias, botão WhatsApp em destaque; menu hambúrguer no mobile.
3. Hero carrossel (2 banners enviados) com headline "DO CLÁSSICO AO LANÇAMENTO" e CTA "Fale no WhatsApp".
4. Faixa de 4 selos de confiança.
5. Grade de categorias com glow: PlayStation, Xbox, Nintendo, Retrô & Seminovos, PC Gamer, Acessórios.
6. Seções por categoria (PlayStation, Xbox, Nintendo, PC Gamer, Acessórios) com carrossel/grade de cards.
7. Seção retrô "Clássicos que marcaram gerações" com scanline/CRT, borda pixelada e grade synthwave.
8. "Venha visitar nossa loja física": foto, texto, botões "Como chegar" (Google Maps) e "Chamar no WhatsApp".
9. Rodapé: contatos, redes sociais, links institucionais, ícones de pagamento (Pix, Visa, Master, boleto).
10. Botão flutuante do WhatsApp fixo (todas as telas).

## Card de produto
Imagem, etiqueta de condição (Novo azul / Seminovo roxo / Retrô magenta), nome, preço em destaque, linha "à vista no Pix" opcional, botão único "Comprar no WhatsApp". Hover: borda acende + card sobe.

## Dados
`src/data/produtos.ts` — array editável com `id, nome, categoria, condicao, preco, precoPix?, imagem, descricao`. 4–6 produtos por categoria (PS5, PS2, Mega Drive, Switch 2, Xbox Series X, PC Gamer, acessórios). Imagens de produto e foto da loja geradas no estilo do site.

## Detalhes técnicos
- Tudo em `src/routes/index.tsx` (substitui o placeholder) + componentes em `src/components/newgames/`.
- Tokens neon, gradientes, glow, grid retrô e scanline definidos em `src/styles.css` (Tailwind v4 `@theme`).
- Banners enviados publicados como assets de CDN; carrossel simples com autoplay e swipe.
- SEO: `head()` próprio na rota com título/descrição/OG da NewGames.
- Placeholders a trocar depois: número do WhatsApp (`55SEUNUMERO`), endereço, horário, link do Maps, redes sociais e o `Logo.png` (uso um logotipo neon provisório até o envio).
